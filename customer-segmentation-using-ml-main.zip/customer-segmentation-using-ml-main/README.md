In this machine learning project, I went through the customer segmentation model. I developed this using using unsupervised learning. 
I analysed the data and then used K-means and Hierarchical clustering algorithm on it.
